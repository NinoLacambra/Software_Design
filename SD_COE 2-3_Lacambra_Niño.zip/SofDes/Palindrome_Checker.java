package SofDes;

public class Palindrome_Checker {

	public static void main(String[] args) {
		//Given
		String original = "racecar";
		String reversed = "";
		
		//Insert code solution here
		for (int i = original.length() - 1; i >= 0; i--) {
            reversed += original.charAt(i);
        }

        // Compare the original and reversed strings
        if (original.equals(reversed)) {
            System.out.println("The string is a palindrome.");
        } else {
            System.out.println("The string is not a palindrome.");
        }

	}

}
