package Java_DataStructure;

import java.util.Scanner;

public class BinarytoDecimal {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
			int N = scanner.nextInt();
			scanner.nextLine(); // Read the newline character after N

			for (int i = 0; i < N; i++) {
			    String binary = scanner.nextLine();
			    int decimal = convertBinaryToDecimal(binary);
			    System.out.println(decimal);
			}
		}
    }

    private static int convertBinaryToDecimal(String binary) {
        int decimal = 0;
        int power = 0;

        for (int i = binary.length() - 1; i >= 0; i--) {
            int bit = binary.charAt(i) - '0';
            decimal += bit * Math.pow(2, power);
            power++;
        }

        return decimal;
    }
}