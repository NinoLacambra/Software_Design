package Java_DataStructure;

import java.util.Scanner;
import java.util.Stack;

public class Parenthesis_Checker {
	public static void main(String[] args) {
		 try (Scanner scanner = new Scanner(System.in)) {
			int N = scanner.nextInt();
	        scanner.nextLine(); // Read the newline character after N

	        for (int i = 0; i < N; i++) {
	            String parentheses = scanner.nextLine();
	            if (isBalanced(parentheses)) {
	                System.out.println("BALANCED");
	            } else {
	                System.out.println("NOT BALANCED");
	            }
	        }
		}
	    }

	    private static boolean isBalanced(String parentheses) {
	        Stack<Character> stack = new Stack<>();

	        for (char c : parentheses.toCharArray()) {
	            if (c == '(' || c == '{') {
	                stack.push(c);
	            } else if (c == ')' || c == '}') {
	                if (stack.isEmpty()) {
	                    return false; // Unbalanced, no opening parenthesis to match
	                }

	                char top = stack.pop();

	                if ((c == ')' && top != '(') || (c == '}' && top != '{')) {
	                    return false; // Unbalanced, mismatched parenthesis
	                }
	            }
	        }

	        return stack.isEmpty(); // Balanced if the stack is empty
	    }
	}